import cv2
import numpy as np
from colorama import init, Fore, Style
import os

# Initialize colorama
init(autoreset=True)

# Load YOLOv3 model
net = cv2.dnn.readNet(
    "C:/Users/nithe/Downloads/yolov3.weights",
    "C:/Users/nithe/Downloads/yolov3.cfg"
)

# Load COCO class names
with open("C:/Users/nithe/Downloads/coco.names", "r") as f:
    classes = f.read().splitlines()

# Vehicle class IDs from COCO (Car, Motorcycle, Bus, Truck)
vehicle_classes = [2, 3, 5, 7]

# Video stream URL (HLS)
video_url = "https://media-sfs7.vdotcameras.com/rtplive/RichmondCS064EB1840/chunklist_w263644306.m3u8"

# Clear console function
def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

# Preprocessing function
def preprocess_frame(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    equalized = cv2.equalizeHist(gray)
    equalized_bgr = cv2.cvtColor(equalized, cv2.COLOR_GRAY2BGR)
    blurred = cv2.GaussianBlur(equalized_bgr, (5, 5), 0)
    resized = cv2.resize(blurred, (416, 416))
    return resized

# Vehicle detection function
def detect_vehicles(frame):
    height, width = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(preprocess_frame(frame), 0.00392, (416, 416), (0, 0, 0), True, crop=False)
    net.setInput(blob)
    outputs = net.forward(net.getUnconnectedOutLayersNames())

    boxes = []
    confidences = []

    for output in outputs:
        for detection in output:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.5 and class_id in vehicle_classes:
                center_x = int(detection[0] * width)
                center_y = int(detection[1] * height)
                w = int(detection[2] * width)
                h = int(detection[3] * height)
                x = int(center_x - w / 2)
                y = int(center_y - h / 2)
                boxes.append([x, y, w, h])
                confidences.append(float(confidence))

    indices = cv2.dnn.NMSBoxes(boxes, confidences, 0.5, 0.4)
    unique_boxes = [boxes[i] for i in indices.flatten()] if indices is not None and len(indices) > 0 else []

    return len(unique_boxes), unique_boxes

# Congestion classification
def get_congestion_level(count):
    if count < 5:
        return "Low"
    elif count < 15:
        return "Moderate"
    else:
        return "High"

# Open video stream
cap = cv2.VideoCapture(video_url, cv2.CAP_FFMPEG)

while True:
    ret, frame = cap.read()
    if not ret:
        print("Error reading frame. Exiting.")
        break

    vehicle_count, boxes = detect_vehicles(frame)
    congestion = get_congestion_level(vehicle_count)

    # Clear console for clean display
    clear_console()

    # Select color and emoji for congestion level
    if congestion == "Low":
        color = Fore.GREEN
        emoji = "🟢"
    elif congestion == "Moderate":
        color = Fore.YELLOW
        emoji = "🟡"
    else:
        color = Fore.RED
        emoji = "🔴"

    # Pretty terminal output
    print(f"{Fore.CYAN + Style.BRIGHT}{'='*40}")
    print(f"{Fore.WHITE + Style.BRIGHT}🚗 VEHICLE MONITORING SYSTEM")
    print(f"{Fore.CYAN + Style.BRIGHT}{'='*40}")
    print(f"{Fore.WHITE}Detected Vehicles: {Fore.MAGENTA}{vehicle_count}")
    print(f"{Fore.WHITE}Congestion Level : {color + Style.BRIGHT}{congestion} {emoji}")
    print(f"{Fore.CYAN + Style.BRIGHT}{'='*40}\n")

    # Show video stream
    cv2.imshow('Traffic Detection', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release resources
cap.release()
cv2.destroyAllWindows()
