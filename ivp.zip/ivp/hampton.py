import cv2
import numpy as np
from colorama import init, Fore, Style
import os

init(autoreset=True)

# Load YOLOv3 model
net = cv2.dnn.readNet(
    "C:/Users/nithe/Downloads/yolov3.weights",
    "C:/Users/nithe/Downloads/yolov3.cfg"
)

# Load COCO class names
with open("C:/Users/nithe/Downloads/coco.names", "r") as f:
    classes = f.read().splitlines()

vehicle_classes = [2, 3, 5, 7]  # Car, Motorcycle, Bus, Truck
video_url = "https://media-sfs4.vdotcameras.com/rtplive/HamptonRoads814/chunklist_w660643749.m3u8"

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

def get_congestion_level(count):
    if count < 5:
        return "Low", Fore.GREEN + "🟢"
    elif count < 15:
        return "Moderate", Fore.YELLOW + "🟡"
    else:
        return "High", Fore.RED + "🔴"

def detect_vehicles(frame):
    height, width = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(frame, 0.00392, (416, 416), (0, 0, 0), True, crop=False)
    net.setInput(blob)
    outputs = net.forward(net.getUnconnectedOutLayersNames())

    left_count, right_count = 0, 0
    boxes = []

    for output in outputs:
        for detection in output:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.5 and class_id in vehicle_classes:
                center_x = int(detection[0] * width)
                center_y = int(detection[1] * height)
                w = int(detection[2] * width)
                h = int(detection[3] * height)
                x = int(center_x - w / 2)
                y = int(center_y - h / 2)

                # Determine lane based on center_x
                if center_x < width // 2:
                    left_count += 1
                else:
                    right_count += 1

                boxes.append((x, y, w, h, class_id))

    return left_count, right_count, boxes

# Start video
cap = cv2.VideoCapture(video_url, cv2.CAP_FFMPEG)

while True:
    ret, frame = cap.read()
    if not ret:
        print("Error reading frame. Exiting.")
        break

    left_count, right_count, boxes = detect_vehicles(frame)
    left_cong, left_emoji = get_congestion_level(left_count)
    right_cong, right_emoji = get_congestion_level(right_count)

    clear_console()
    print(f"{Fore.CYAN + Style.BRIGHT}{'='*50}")
    print(f"{Fore.WHITE + Style.BRIGHT}🚗 VEHICLE MONITORING SYSTEM (PER LANE)")
    print(f"{Fore.CYAN + Style.BRIGHT}{'='*50}")
    print(f"{Fore.BLUE + Style.BRIGHT}LEFT LANE")
    print(f"{Fore.WHITE}Detected Vehicles: {Fore.MAGENTA}{left_count}")
    print(f"{Fore.WHITE}Congestion Level : {left_cong} {left_emoji}\n")
    print(f"{Fore.BLUE + Style.BRIGHT}RIGHT LANE")
    print(f"{Fore.WHITE}Detected Vehicles: {Fore.MAGENTA}{right_count}")
    print(f"{Fore.WHITE}Congestion Level : {right_cong} {right_emoji}")
    print(f"{Fore.CYAN + Style.BRIGHT}{'='*50}\n")

    # Optional: Draw bounding boxes
    for x, y, w, h, class_id in boxes:
        label = classes[class_id]
        color = (0, 255, 0) if x + w//2 < frame.shape[1] // 2 else (0, 0, 255)
        cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
        cv2.putText(frame, label, (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

    # Draw lane divider
    mid = frame.shape[1] // 2
    cv2.line(frame, (mid, 0), (mid, frame.shape[0]), (255, 255, 255), 2)

    cv2.imshow('Traffic Detection (Per Lane)', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()




